// ============================================================================
// PASEON POPUP v0.4.0
// ============================================================================

let selectedTabId = null;

function popLog(text, type = "info") {
  console.log(`[PASEON-POPUP] ${text}`);
  const area = document.getElementById("log-area");
  const entry = document.createElement("div");
  entry.className = `log-entry ${type === "ok" ? "ok" : type === "err" ? "err" : ""}`;
  entry.textContent = `[${new Date().toLocaleTimeString()}] ${text}`;
  area.prepend(entry);
  while (area.children.length > 40) area.removeChild(area.lastChild);
}

function getSiteName(url) {
  if (!url) return "?";
  if (url.includes("chatgpt.com") || url.includes("chat.openai.com")) return "ChatGPT";
  if (url.includes("gemini.google.com")) return "Gemini";
  if (url.includes("grok.com")) return "Grok";
  if (url.includes("chat.deepseek.com")) return "DeepSeek";
  if (url.includes("deepseek.com")) return "DeepSeek🏠";
  if (url.includes("meta.ai")) return "Meta AI";
  if (url.includes("claude.ai")) return "Claude";
  if (url.includes("copilot.microsoft.com")) return "Copilot";
  if (url.includes("perplexity.ai")) return "Perplexity";
  if (url.includes("chat.mistral.ai")) return "Mistral";
  return "AI";
}

function checkServer() {
  chrome.runtime.sendMessage({ type: "PASEON_HEALTH_CHECK" }, (res) => {
    const dot = document.getElementById("server-dot");
    const status = document.getElementById("server-status");
    if (chrome.runtime.lastError || !res || res.status === "offline") {
      dot.className = "dot offline";
      status.textContent = "KAPALI ✗";
      popLog("Sunucu kapalı!", "err");
    } else {
      dot.className = "dot online";
      status.textContent = "AÇIK ✓";
      popLog("Sunucu OK", "ok");
    }
  });
}

function refreshTabs() {
  chrome.runtime.sendMessage({ type: "PASEON_LIST_TABS" }, (res) => {
    if (chrome.runtime.lastError || !res) {
      popLog("Sekme taraması başarısız", "err");
      return;
    }

    const tabs = res.tabs || [];
    const container = document.getElementById("tabs-list");
    container.innerHTML = "";

    if (tabs.length === 0) {
      container.innerHTML = '<em style="color:#555">AI sekmesi bulunamadı</em>';
      popLog("Açık AI sekmesi yok");
      return;
    }

    tabs.forEach(tab => {
      const div = document.createElement("div");
      const siteName = getSiteName(tab.url);
      div.className = "tab-item" + (tab.id === selectedTabId ? " selected" : "");
      div.innerHTML = `<span class="tab-site">[${siteName}]</span> ${(tab.title || "").substring(0, 35)}`;
      div.addEventListener("click", () => {
        selectedTabId = tab.id;
        popLog(`Seçildi: [${siteName}] tab=${tab.id}`, "ok");
        refreshTabs();
      });
      container.appendChild(div);
    });

    if (!selectedTabId && tabs.length > 0) {
      selectedTabId = tabs[0].id;
    }

    popLog(`${tabs.length} AI sekmesi bulundu`);
  });
}

function sendToTab(type, extra = {}) {
  if (!selectedTabId) {
    popLog("Sekme seçilmedi!", "err");
    return;
  }
  chrome.tabs.sendMessage(selectedTabId, { type, ...extra }, (res) => {
    if (chrome.runtime.lastError) {
      popLog(`Hata: ${chrome.runtime.lastError.message}`, "err");
      return;
    }
    popLog(`${type}: ${JSON.stringify(res)}`, res?.status === "error" ? "err" : "ok");
  });
}

document.getElementById("btn-inject").addEventListener("click", () => {
  const prompt = document.getElementById("prompt-input").value.trim();
  if (!prompt) { popLog("Prompt boş!", "err"); return; }
  if (!selectedTabId) { popLog("Sekme seç!", "err"); return; }
  chrome.runtime.sendMessage({ type: "PASEON_SEND_TO_TAB", tabId: selectedTabId, prompt }, (res) => {
    if (chrome.runtime.lastError) {
      popLog(`Enjeksiyon hata: ${chrome.runtime.lastError.message}`, "err");
      return;
    }
    popLog(`Enjeksiyon: ${res?.status}`, res?.status === "injected" ? "ok" : "err");
  });
});

document.getElementById("btn-capture").addEventListener("click", () => sendToTab("PASEON_CAPTURE_NOW"));
document.getElementById("btn-inspect").addEventListener("click", () => sendToTab("PASEON_INSPECT"));
document.getElementById("btn-watch").addEventListener("click", () => sendToTab("PASEON_START_WATCH"));
document.getElementById("btn-refresh").addEventListener("click", () => {
  popLog("Yenileniyor...");
  checkServer();
  refreshTabs();
});

checkServer();
refreshTabs();
