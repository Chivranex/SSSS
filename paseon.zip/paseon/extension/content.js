// ============================================================================
// PASEON CONTENT SCRIPT v0.4.0
// ============================================================================
// FIXES: Copilot testid selectors, Gemini response selectors,
//        Claude/MetaAI initialization, DeepSeek chat URL,
//        Extension element filtering, minimum text length
// ============================================================================

const PREFIX = "[PASEON-DEBUG]";
const RELAY_URL = "http://localhost:3000/log";
const MIN_RESPONSE_LENGTH = 20;      // Ignore captures shorter than this
const DEBOUNCE_MS = 3500;            // Wait for streaming to finish
const INIT_DELAY_MS = 3000;          // Wait for SPA to load
const RETRY_INIT_MS = 5000;          // Retry if first init finds nothing

// ---------------------------------------------------------------------------
// 0. SAFE LOGGER (wrapped in try-catch to never crash)
// ---------------------------------------------------------------------------
function pLog(level, ...args) {
  try {
    const ts = new Date().toISOString();
    const tag = `${PREFIX} [${level.toUpperCase()}] [${ts}]`;
    if (level === "error") console.error(tag, ...args);
    else if (level === "warn") console.warn(tag, ...args);
    else console.log(tag, ...args);
  } catch (e) { /* never crash on logging */ }
}

// ---------------------------------------------------------------------------
// 1. SITE DETECTION
// ---------------------------------------------------------------------------
function detectSite() {
  const host = window.location.hostname;
  const url = window.location.href;
  pLog("info", `Site tespiti. Hostname: ${host}, URL: ${url}`);

  const siteMap = [
    { domains: ["chatgpt.com", "chat.openai.com"], name: "chatgpt" },
    { domains: ["gemini.google.com"], name: "gemini" },
    { domains: ["grok.com"], name: "grok" },
    { domains: ["chat.deepseek.com"], name: "deepseek" },
    { domains: ["www.deepseek.com", "deepseek.com"], name: "deepseek_home" },
    { domains: ["www.meta.ai", "meta.ai"], name: "metaai" },
    { domains: ["claude.ai"], name: "claude" },
    { domains: ["copilot.microsoft.com"], name: "copilot" },
    { domains: ["www.perplexity.ai", "perplexity.ai"], name: "perplexity" },
    { domains: ["chat.mistral.ai"], name: "mistral" },
  ];

  for (const site of siteMap) {
    for (const domain of site.domains) {
      if (host === domain || host.endsWith("." + domain)) {
        pLog("info", `✅ Site tespit edildi: ${site.name} (${domain})`);
        return site.name;
      }
    }
  }

  pLog("warn", `⚠️ Bilinmeyen site: ${host}`);
  return "unknown";
}

// ---------------------------------------------------------------------------
// 2. JUNK FILTER - Filters out extension UI, cookie notices, footers etc.
// ---------------------------------------------------------------------------
function isJunkElement(el) {
  try {
    const cls = el.className?.toString() || "";

    // Filter out browser extension elements (Immersive Translate etc.)
    // These have very long hex-based class names
    if (/[a-f0-9]{20,}/.test(cls)) return true;

    // Filter out elements from known extension patterns
    if (cls.includes("immersive-translate")) return true;
    if (cls.includes("notranslate") && cls.length < 20) return false; // notranslate is ok

    return false;
  } catch (e) { return false; }
}

function isJunkText(text) {
  if (!text || text.length < MIN_RESPONSE_LENGTH) return true;

  const lower = text.toLowerCase().trim();

  // Cookie notices
  if (lower.includes("we use cookies") && lower.length < 300) return true;
  if (lower.includes("cookie policy") && lower.length < 300) return true;

  // Footer/copyright junk
  if (lower.startsWith("© 20") && lower.length < 500) return true;
  if (lower.includes("all rights reserved") && lower.includes("privacy policy") && lower.length < 600) return true;

  // Navigation/sidebar text (list of short items)
  const lines = text.split("\n").filter(l => l.trim().length > 0);
  if (lines.length > 5 && lines.every(l => l.trim().length < 50)) {
    // Looks like a menu/sidebar list
    const avgLen = lines.reduce((s, l) => s + l.trim().length, 0) / lines.length;
    if (avgLen < 30) return true;
  }

  // Language selector lists
  if (lower.includes("afrikaans") && lower.includes("deutsch") && lower.includes("français")) return true;

  // UI text patterns
  if (lower.startsWith("history\n") && lower.includes("discover")) return true;
  if (lower.includes("ask anything") && lower.length < 300) return true;

  return false;
}

// ---------------------------------------------------------------------------
// 3. SITE CONFIGS - Based on REAL discovery data from your logs
// ---------------------------------------------------------------------------
function getSiteConfig(site) {
  pLog("info", `Config yükleniyor: ${site}`);

  const configs = {
    // ─── ChatGPT (WORKING) ────────────────────────────────────
    chatgpt: {
      chatContainer: "main",
      responseSelectors: [
        'div[data-message-author-role="assistant"] div.markdown',
        'div[data-message-author-role="assistant"]',
        "div.markdown.prose",
      ],
    },

    // ─── Gemini ───────────────────────────────────────────────
    // Gemini uses web components. Responses are inside model-response > message-content
    // The sidebar with chat titles should be excluded.
    gemini: {
      chatContainer: "main, .conversation-container",
      responseSelectors: [
        // Gemini primary: model response content
        "model-response .message-content",
        "model-response message-content",
        "model-response",
        ".model-response-text",
        // Gemini markdown
        ".markdown-main-panel",
        'div[class*="model-response"]',
        'div[class*="response-content"]',
        // Gemini message bubbles
        'div[data-content-type="response"]',
        ".response-container message-content",
        ".response-container",
      ],
    },

    // ─── Claude ───────────────────────────────────────────────
    // Claude uses React with specific class patterns
    claude: {
      chatContainer: 'div[class*="conversation"], main, div[class*="thread"]',
      responseSelectors: [
        // Claude's actual response containers
        'div[data-is-streaming]',
        'div.font-claude-message',
        'div[class*="font-claude"]',
        // Grid-based message layout
        'div.grid-cols-1 > div.contents > div',
        // Prose/markdown inside messages  
        'div[class*="message"] div.prose',
        'div[class*="message"] div[class*="markdown"]',
        // Broader fallbacks
        'div[class*="assistant"] div.prose',
        'div[class*="assistant-message"]',
        'div.prose',
        'div[class*="message-content"]',
      ],
    },

    // ─── Grok (WORKING) ──────────────────────────────────────
    grok: {
      chatContainer: "main, div[class*='chat'], div[class*='conversation']",
      responseSelectors: [
        'div[class*="message"][class*="bot"]',
        'div[class*="message"][class*="assistant"]',
        'div[class*="response"]',
        "div.prose",
        'div[class*="markdown"]',
        "div.message-content",
        'div[data-role="assistant"]',
      ],
    },

    // ─── DeepSeek (chat page) ─────────────────────────────────
    deepseek: {
      chatContainer: "main, div[class*='chat'], div[class*='conversation']",
      responseSelectors: [
        'div[class*="ds-markdown"]',
        'div[class*="message"][class*="assistant"]',
        'div[class*="bot-message"]',
        'div[class*="answer"]',
        "div.prose",
        'div[class*="markdown"]',
        'div[data-role="assistant"]',
      ],
    },

    // DeepSeek homepage - just detect, don't capture junk
    deepseek_home: {
      chatContainer: "main, body",
      responseSelectors: [
        'div[class*="ds-markdown"]',
        'div[class*="chat-message"]',
        'div[class*="answer"]',
      ],
    },

    // ─── Meta AI ──────────────────────────────────────────────
    metaai: {
      chatContainer: 'div[role="main"], main, div[class*="chat"]',
      responseSelectors: [
        // Meta AI message patterns
        'div[class*="message"][class*="assistant"]',
        'div[class*="bot-message"]',
        'div[class*="response-message"]',
        'div[class*="ai-message"]',
        'div[data-role="assistant"]',
        // Broader patterns
        'div[class*="prose"]',
        'div[class*="markdown"]',
        'div[class*="response"]',
      ],
    },

    // ─── Copilot (FIXED) ──────────────────────────────────────
    // Discovery showed: div[data-testid="ai-message"] is the key!
    // Inside: div.group/ai-message-item.space-y-3.break-words
    copilot: {
      chatContainer: 'div[data-testid="chat-page"], main',
      responseSelectors: [
        // PRIMARY: Exact selector from discovery
        'div[data-testid="ai-message"] div[class*="ai-message-item"]',
        'div[data-testid="ai-message"]',
        // Fallbacks
        'div[class*="ai-message-item"]',
        'div[class*="space-y-3"][class*="break-words"]',
      ],
    },

    // ─── Perplexity (PARTIALLY WORKING) ───────────────────────
    perplexity: {
      chatContainer: "main, div[class*='chat']",
      responseSelectors: [
        'div[class*="prose"]',
        'div[class*="answer"]',
        'div[class*="response"]',
        'div[class*="markdown"]',
        'div[data-role="assistant"]',
        'div[class*="result-content"]',
      ],
    },

    // ─── Mistral (WORKING) ────────────────────────────────────
    mistral: {
      chatContainer: "main, div[class*='chat']",
      responseSelectors: [
        'div[class*="assistant"]',
        'div[class*="prose"]',
        'div[class*="markdown"]',
        'div[data-role="assistant"]',
        'div[class*="message-content"]',
      ],
    },

    // ─── UNKNOWN ──────────────────────────────────────────────
    unknown: {
      chatContainer: "main, body",
      responseSelectors: [
        'div[class*="markdown"]',
        "div.prose",
        'div[class*="response"]',
        'div[class*="assistant"]',
      ],
    },
  };

  return configs[site] || configs["unknown"];
}

// ---------------------------------------------------------------------------
// 4. FIND RESPONSES (with junk filtering)
// ---------------------------------------------------------------------------
function findResponses(config, site) {
  let found = [];

  // Try defined selectors
  for (const sel of config.responseSelectors) {
    try {
      const els = document.querySelectorAll(sel);
      if (els.length > 0) {
        pLog("info", `🎯 "${sel}" → ${els.length} element`);
        els.forEach(el => {
          if (!found.includes(el) && !isJunkElement(el)) {
            found.push(el);
          }
        });
      }
    } catch (e) { /* invalid selector, skip */ }
  }

  // Fallback: scan for long text divs
  if (found.length === 0) {
    pLog("warn", "⚠️ Seçiciler boş. Fallback: uzun metin taraması...");
    const container = document.querySelector("main") || document.body;
    const allDivs = container.querySelectorAll("div");

    for (const div of allDivs) {
      if (isJunkElement(div)) continue;

      const text = (div.innerText || "").trim();
      if (text.length < MIN_RESPONSE_LENGTH) continue;
      if (isJunkText(text)) continue;

      // Check this isn't a parent of an already-found element
      const isDuplicate = Array.from(div.children).some(
        c => c.innerText && c.innerText.length > text.length * 0.8
      );
      if (!isDuplicate && found.length < 20) {
        pLog("info", `🔍 Fallback: ${text.length}c class="${(div.className?.toString() || "").substring(0, 60)}"`);
        found.push(div);
      }
    }
  }

  pLog("info", `findResponses: ${found.length} toplam (filtered)`);
  return found;
}

// ---------------------------------------------------------------------------
// 5. EXTRACT CLEAN TEXT from an element
// ---------------------------------------------------------------------------
function extractText(el) {
  try {
    let text = (el.innerText || el.textContent || "").trim();
    // Remove excessive whitespace
    text = text.replace(/\n{3,}/g, "\n\n").trim();
    return text;
  } catch (e) { return ""; }
}

// ---------------------------------------------------------------------------
// 6. MUTATION OBSERVER
// ---------------------------------------------------------------------------
let currentObserver = null;
let debounceTimer = null;
let lastCapturedText = "";
let lastCaptureTime = 0;

function startWatching(site, config) {
  pLog("info", "=== OBSERVER KURULUYOR ===");

  if (currentObserver) {
    currentObserver.disconnect();
    pLog("info", "Önceki observer kapatıldı.");
  }

  // Find chat container
  let target = null;
  for (const sel of config.chatContainer.split(",").map(s => s.trim())) {
    try { target = document.querySelector(sel); } catch (e) {}
    if (target) break;
  }
  if (!target) {
    target = document.body;
    pLog("warn", "Chat container bulunamadı → document.body");
  }

  pLog("info", `Observer hedefi: <${target.tagName}>#${target.id || "(no-id)"}`);

  currentObserver = new MutationObserver(() => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => captureAndSend(site, config), DEBOUNCE_MS);
  });

  currentObserver.observe(target, { childList: true, subtree: true, characterData: true });
  pLog("info", `✅ Observer aktif. Debounce: ${DEBOUNCE_MS}ms`);
}

// ---------------------------------------------------------------------------
// 7. CAPTURE & SEND
// ---------------------------------------------------------------------------
function captureAndSend(site, config) {
  pLog("info", "🔍 Yanıt taraması...");

  const els = findResponses(config, site);
  if (els.length === 0) {
    pLog("debug", "Yanıt bulunamadı.");
    return;
  }

  // Get the last element's text
  const lastEl = els[els.length - 1];
  const text = extractText(lastEl);

  if (!text || text.length < MIN_RESPONSE_LENGTH) {
    pLog("debug", `Metin çok kısa (${text.length}c), atlıyorum.`);
    return;
  }

  // Filter junk
  if (isJunkText(text)) {
    pLog("debug", "Junk metin, atlıyorum.");
    return;
  }

  // Don't resend same text
  if (text === lastCapturedText && Date.now() - lastCaptureTime < 15000) {
    pLog("debug", "Aynı yanıt, atlıyorum.");
    return;
  }

  pLog("info", `📝 YAKALANDI! [${site}] ${text.length} karakter`);
  pLog("info", `Önizleme: "${text.substring(0, 200)}"`);

  lastCapturedText = text;
  lastCaptureTime = Date.now();

  const payload = {
    timestamp: new Date().toISOString(),
    source: site,
    url: window.location.href,
    responseText: text,
    charCount: text.length,
    totalElements: els.length,
    captureMode: "auto",
    elementInfo: {
      tagName: lastEl.tagName,
      className: (lastEl.className?.toString() || "").substring(0, 120),
    },
  };

  relay(payload);
}

// ---------------------------------------------------------------------------
// 8. MANUAL CAPTURE
// ---------------------------------------------------------------------------
function manualCaptureAll(site, config) {
  pLog("info", "📸 Manuel yakalama başlıyor...");

  const els = findResponses(config, site);
  const texts = Array.from(els)
    .map(el => extractText(el))
    .filter(t => t.length >= MIN_RESPONSE_LENGTH && !isJunkText(t));

  pLog("info", `Manuel: ${texts.length} temiz yanıt bloğu bulundu`);

  if (texts.length > 0) {
    const payload = {
      timestamp: new Date().toISOString(),
      source: site,
      url: window.location.href,
      responseText: texts[texts.length - 1],
      allResponses: texts,
      charCount: texts[texts.length - 1].length,
      totalElements: texts.length,
      captureMode: "manual",
    };
    relay(payload);
  }

  return texts.length;
}

// ---------------------------------------------------------------------------
// 9. RELAY
// ---------------------------------------------------------------------------
function relay(payload) {
  pLog("info", `📡 Gönderiliyor → background`);

  try {
    chrome.runtime.sendMessage({ type: "PASEON_RELAY", payload }, (res) => {
      if (chrome.runtime.lastError) {
        pLog("warn", `BG hata: ${chrome.runtime.lastError.message}. Direct fetch...`);
        directFetch(payload);
        return;
      }
      pLog("info", `✅ Relay sonuç:`, JSON.stringify(res));
    });
  } catch (err) {
    pLog("error", "sendMessage hata:", err.message);
    directFetch(payload);
  }
}

function directFetch(payload) {
  fetch(RELAY_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  })
    .then(r => r.json())
    .then(d => pLog("info", `✅ Direct OK:`, JSON.stringify(d)))
    .catch(e => pLog("error", `❌ Direct FAIL:`, e.message));
}

// ---------------------------------------------------------------------------
// 10. DEEP DISCOVERY (for debugging)
// ---------------------------------------------------------------------------
function deepDiscovery(site) {
  pLog("info", "");
  pLog("info", "╔══════════════════════════════════════════════════╗");
  pLog("info", `║   DEEP DOM DISCOVERY [${site.toUpperCase().padEnd(12)}]              ║`);
  pLog("info", "╚══════════════════════════════════════════════════╝");

  try {
    // data-testid elements
    const dataEls = document.querySelectorAll("[data-testid], [data-role], [data-message-id], [data-message-author-role], [data-content-type], [data-is-streaming]");
    pLog("info", `[DISC] data-* elementleri: ${dataEls.length}`);
    Array.from(dataEls).slice(0, 25).forEach((el, i) => {
      const attrs = [];
      if (el.dataset.testid) attrs.push(`testid="${el.dataset.testid}"`);
      if (el.dataset.role) attrs.push(`role="${el.dataset.role}"`);
      if (el.dataset.messageAuthorRole) attrs.push(`msgAuthor="${el.dataset.messageAuthorRole}"`);
      if (el.dataset.isStreaming !== undefined) attrs.push(`streaming="${el.dataset.isStreaming}"`);
      if (el.dataset.contentType) attrs.push(`contentType="${el.dataset.contentType}"`);
      const cls = (el.className?.toString() || "").substring(0, 80);
      const txt = (el.innerText || "").substring(0, 50);
      pLog("info", `  [${i}] <${el.tagName}> ${attrs.join(" ")} class="${cls}" text="${txt}"`);
    });

    // Custom elements (Gemini web components)
    const customs = document.querySelectorAll("message-content, model-response, response-container, cib-message-group, rich-textarea, chat-message, assistant-message");
    pLog("info", `[DISC] Custom elementler: ${customs.length}`);
    customs.forEach((el, i) => {
      pLog("info", `  [${i}] <${el.tagName.toLowerCase()}> class="${(el.className?.toString() || "").substring(0, 60)}" text=${(el.innerText || "").length}chars preview="${(el.innerText || "").substring(0, 60)}"`);
    });

    // Markdown / prose / response / assistant elements
    const markedEls = document.querySelectorAll('[class*="markdown"], [class*="prose"], [class*="response"], [class*="assistant"], [class*="ai-message"], [class*="bot-message"], [class*="font-claude"]');
    pLog("info", `[DISC] Önemli class pattern'leri: ${markedEls.length}`);
    Array.from(markedEls).slice(0, 20).forEach((el, i) => {
      if (isJunkElement(el)) return;
      const txt = (el.innerText || "").substring(0, 60);
      pLog("info", `  [${i}] <${el.tagName}> class="${(el.className?.toString() || "").substring(0, 90)}" text="${txt}" ${(el.innerText || "").length}c`);
    });

    // Main structure
    const main = document.querySelector("main") || document.querySelector('[role="main"]');
    if (main) {
      pLog("info", `[DISC] <main> yapısı (L1):`);
      Array.from(main.children).slice(0, 8).forEach((c1, i) => {
        pLog("info", `  L1[${i}] <${c1.tagName}> class="${(c1.className?.toString() || "").substring(0, 60)}" children=${c1.children.length} text=${(c1.innerText || "").length}c`);
      });
    }

    // Input areas
    const inputs = document.querySelectorAll('textarea, [contenteditable="true"], .ProseMirror, .ql-editor');
    pLog("info", `[DISC] Input alanları: ${inputs.length}`);
    inputs.forEach((el, i) => {
      if (isJunkElement(el)) return;
      pLog("info", `  [${i}] <${el.tagName}> id="${el.id}" class="${(el.className?.toString() || "").substring(0, 60)}" placeholder="${(el.placeholder || "").substring(0, 40)}"`);
    });

    // Long text scan (clean only)
    pLog("info", "[DISC] Temiz uzun metinler (>50 char, junk filtreli):");
    const allDivs = (main || document.body).querySelectorAll("div");
    let count = 0;
    allDivs.forEach((div) => {
      if (isJunkElement(div)) return;
      const text = (div.innerText || "").trim();
      if (text.length > 50 && count < 10) {
        if (isJunkText(text)) return;
        const hasChildSameText = Array.from(div.children).some(c => c.innerText && c.innerText.length > text.length * 0.8);
        if (!hasChildSameText) {
          count++;
          pLog("info", `  [LT-${count}] <${div.tagName}> class="${(div.className?.toString() || "").substring(0, 70)}" ${text.length}c → "${text.substring(0, 100)}"`);
        }
      }
    });

  } catch (err) {
    pLog("error", "💥 deepDiscovery HATA:", err.message);
  }

  pLog("info", "═══ DISCOVERY BİTTİ ═══\n");
}

// ---------------------------------------------------------------------------
// 11. PROMPT INJECTION
// ---------------------------------------------------------------------------
function injectPrompt(text) {
  const site = detectSite();
  pLog("info", `=== ENJEKSİYON === ${text.length} karakter [${site}]`);

  try {
    // Site-specific input selectors
    const inputSelectors = {
      chatgpt: '#prompt-textarea, div[id="prompt-textarea"]',
      gemini: '.ql-editor, div[contenteditable="true"], textarea',
      claude: 'div.ProseMirror, div[contenteditable="true"]',
      grok: 'textarea, div[contenteditable="true"]',
      deepseek: 'textarea, div[contenteditable="true"]',
      copilot: 'textarea#userInput, textarea[data-testid="composer-input"]',
      perplexity: 'textarea, div[contenteditable="true"]',
      mistral: 'textarea, div[contenteditable="true"]',
      metaai: 'textarea, div[contenteditable="true"]',
    };

    const sels = inputSelectors[site] || 'textarea, div[contenteditable="true"]';
    let inputEl = null;
    for (const sel of sels.split(",").map(s => s.trim())) {
      try {
        inputEl = document.querySelector(sel);
        if (inputEl && !isJunkElement(inputEl)) break;
        inputEl = null;
      } catch (e) {}
    }

    if (!inputEl) {
      pLog("error", "❌ Input bulunamadı.");
      return false;
    }

    if (inputEl.tagName === "TEXTAREA" || inputEl.tagName === "INPUT") {
      const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value")?.set
        || Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")?.set;
      if (setter) setter.call(inputEl, text);
      else inputEl.value = text;
      inputEl.dispatchEvent(new Event("input", { bubbles: true }));
      inputEl.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      inputEl.focus();
      inputEl.innerHTML = "";
      const p = document.createElement("p");
      p.textContent = text;
      inputEl.appendChild(p);
      inputEl.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
    }

    pLog("info", "✅ Metin enjekte edildi.");
    return true;
  } catch (err) {
    pLog("error", "💥 Enjeksiyon HATA:", err.message);
    return false;
  }
}

function triggerSend(site) {
  const sendSelectors = {
    chatgpt: 'button[data-testid="send-button"]',
    gemini: '.send-button, button[aria-label="Send message"], button[aria-label*="Gönder"]',
    claude: 'button[aria-label="Send Message"], button[aria-label*="Send"]',
    grok: 'button[aria-label*="Send"], button[type="submit"]',
    deepseek: 'button[aria-label*="Send"], button[type="submit"]',
    copilot: 'button[data-testid="composer-send-button"], button[aria-label*="Send"]',
    perplexity: 'button[aria-label*="Send"], button[aria-label*="Submit"]',
    mistral: 'button[aria-label*="Send"], button[type="submit"]',
    metaai: 'button[aria-label*="Send"], button[type="submit"]',
  };

  const sels = sendSelectors[site] || 'button[type="submit"]';
  let btn = null;
  for (const sel of sels.split(",").map(s => s.trim())) {
    try { btn = document.querySelector(sel); } catch (e) {}
    if (btn && !btn.disabled) break;
    btn = null;
  }

  if (btn) {
    btn.click();
    pLog("info", "✅ Buton tıklandı.");
  } else {
    pLog("warn", "Buton bulunamadı, Enter simüle...");
  }
}

// ---------------------------------------------------------------------------
// 12. MESSAGE LISTENER
// ---------------------------------------------------------------------------
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  pLog("info", `📩 Mesaj: ${msg.type}`);

  const site = detectSite();
  const config = getSiteConfig(site);

  try {
    switch (msg.type) {
      case "PASEON_INJECT_PROMPT": {
        const ok = injectPrompt(msg.prompt);
        if (ok) {
          startWatching(site, config);
          setTimeout(() => triggerSend(site), 300);
        }
        sendResponse({ status: ok ? "injected" : "failed", site });
        break;
      }
      case "PASEON_INSPECT": {
        deepDiscovery(site);
        sendResponse({ status: "inspected" });
        break;
      }
      case "PASEON_START_WATCH": {
        startWatching(site, config);
        sendResponse({ status: "watching", site });
        break;
      }
      case "PASEON_CAPTURE_NOW": {
        const count = manualCaptureAll(site, config);
        sendResponse({ status: "captured", count });
        break;
      }
      default:
        sendResponse({ status: "unknown_type" });
    }
  } catch (err) {
    pLog("error", "💥 Listener HATA:", err.message);
    sendResponse({ status: "error", message: err.message });
  }

  return true;
});

// ---------------------------------------------------------------------------
// 13. INIT with retry
// ---------------------------------------------------------------------------
(function init() {
  pLog("info", "");
  pLog("info", "╔══════════════════════════════════════════════════╗");
  pLog("info", "║   PASEON CONTENT SCRIPT v0.4.0                   ║");
  pLog("info", "║   9 AI SİTESİ | JUNK FİLTRE | RETRY             ║");
  pLog("info", "╚══════════════════════════════════════════════════╝");
  pLog("info", "");

  const site = detectSite();

  // Don't auto-capture on deepseek homepage
  if (site === "deepseek_home") {
    pLog("info", "⚠️ DeepSeek ana sayfası. Chat sayfası (chat.deepseek.com) değil. Bekleme modunda.");
    return;
  }

  const config = getSiteConfig(site);

  // First attempt after SPA loads
  setTimeout(() => {
    pLog("info", "=== İLK BAŞLATMA ===");
    deepDiscovery(site);

    const els = findResponses(config, site);
    if (els.length > 0) {
      pLog("info", `İlk taramada ${els.length} element bulundu.`);
    } else {
      pLog("warn", "İlk taramada element bulunamadı. Retry zamanlandı...");
    }

    startWatching(site, config);
    pLog("info", `🟢 Paseon v0.4.0 hazır. Site: ${site}`);
  }, INIT_DELAY_MS);

  // Retry for SPAs that load very slowly
  setTimeout(() => {
    const els = findResponses(getSiteConfig(site), site);
    if (els.length === 0) {
      pLog("info", "=== RETRY BAŞLATMA ===");
      deepDiscovery(site);
      startWatching(site, getSiteConfig(site));
    }
  }, INIT_DELAY_MS + RETRY_INIT_MS);

})();
