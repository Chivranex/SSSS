// ============================================================================
// PASEON BACKGROUND SERVICE WORKER v0.4.0
// ============================================================================

const PREFIX = "[PASEON-BG]";
const SERVER_URL = "http://localhost:3000";

const AI_DOMAINS = [
  "chatgpt.com", "chat.openai.com",
  "gemini.google.com",
  "grok.com",
  "deepseek.com", "www.deepseek.com", "chat.deepseek.com",
  "meta.ai", "www.meta.ai",
  "claude.ai",
  "copilot.microsoft.com",
  "perplexity.ai", "www.perplexity.ai",
  "chat.mistral.ai",
];

function pLog(level, ...args) {
  const ts = new Date().toISOString();
  console[level === "error" ? "error" : level === "warn" ? "warn" : "log"](`${PREFIX} [${level.toUpperCase()}] [${ts}]`, ...args);
}

// ---------------------------------------------------------------------------
// MESSAGE HANDLER
// ---------------------------------------------------------------------------
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  pLog("info", `Mesaj: type=${msg.type} tab=${sender.tab?.id || "popup"}`);

  if (msg.type === "PASEON_RELAY") {
    pLog("info", `📡 Relay: source=${msg.payload?.source} chars=${msg.payload?.charCount}`);

    fetch(`${SERVER_URL}/log`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(msg.payload),
    })
      .then(r => r.json())
      .then(d => {
        pLog("info", `✅ Relay OK:`, JSON.stringify(d));
        sendResponse({ status: "relayed", serverResponse: d });
      })
      .catch(e => {
        pLog("error", `❌ Relay FAIL:`, e.message);
        sendResponse({ status: "relay_failed", error: e.message });
      });
    return true;
  }

  if (msg.type === "PASEON_HEALTH_CHECK") {
    fetch(`${SERVER_URL}/status`)
      .then(r => r.json())
      .then(d => sendResponse({ status: "online", serverData: d }))
      .catch(e => sendResponse({ status: "offline", error: e.message }));
    return true;
  }

  if (msg.type === "PASEON_SEND_TO_TAB") {
    chrome.tabs.sendMessage(msg.tabId, { type: "PASEON_INJECT_PROMPT", prompt: msg.prompt }, (res) => {
      if (chrome.runtime.lastError) {
        pLog("error", `Tab mesaj hata:`, chrome.runtime.lastError.message);
        sendResponse({ status: "error", error: chrome.runtime.lastError.message });
      } else {
        sendResponse(res);
      }
    });
    return true;
  }

  if (msg.type === "PASEON_LIST_TABS") {
    chrome.tabs.query({}, (tabs) => {
      const aiTabs = tabs.filter(t =>
        t.url && AI_DOMAINS.some(d => t.url.includes(d))
      );
      pLog("info", `${aiTabs.length} AI tab / ${tabs.length} toplam`);
      sendResponse({
        status: "ok",
        tabs: aiTabs.map(t => ({
          id: t.id,
          title: t.title,
          url: t.url,
          favIconUrl: t.favIconUrl,
        })),
      });
    });
    return true;
  }
});

chrome.runtime.onInstalled.addListener((details) => {
  pLog("info", `Paseon v0.4.0 kuruldu. Sebep: ${details.reason}`);
});

pLog("info", "🟢 Paseon BG v0.4.0 yüklendi.");
