# PASEON MVP - Kurulum & Test Talimatları

## Dosya Yapısı

```
paseon/
├── extension/          ← Chrome Eklentisi
│   ├── manifest.json   ← Manifest V3 tanımı
│   ├── content.js      ← DOM enjeksiyonu + MutationObserver
│   ├── background.js   ← CORS köprüsü (Service Worker)
│   ├── popup.html      ← Kontrol paneli arayüzü
│   └── popup.js        ← Popup mantığı
└── server/             ← Localhost Sunucusu
    ├── package.json    ← Bağımlılıklar
    └── server.js       ← Express sunucusu (/status, /log, /logs)
```

---

## ADIM 1: Sunucuyu Başlat (Kali Terminal)

```bash
cd paseon/server
npm install
node server.js
```

Terminalde şunu görmelisin:
```
[PASEON-SERVER] ╔══════════════════════════════════════════╗
[PASEON-SERVER] ║   PASEON SERVER v0.1.0 BAŞLATILDI        ║
[PASEON-SERVER] ╠══════════════════════════════════════════╣
[PASEON-SERVER] ║ Adres  : http://localhost:3000            ║
[PASEON-SERVER] ╚══════════════════════════════════════════╝
```

**Doğrulama:** ChromeOS tarayıcısında `http://localhost:3000/status` adresine git. JSON yanıt görmelisin.

---

## ADIM 2: Chrome Eklentisini Yükle

1. Chrome'da `chrome://extensions` adresine git.
2. Sağ üstten **"Geliştirici modu"** (Developer mode) toggle'ını AÇ.
3. **"Paketlenmemiş öğe yükle"** (Load unpacked) butonuna tıkla.
4. `paseon/extension` klasörünü seç.
5. Eklenti listesinde **"Paseon - AI Aggregator Bridge"** görünmeli.

> **NOT (Chromebook):** `extension` klasörünün Linux dosyaları altında (`/home/kullanici/paseon/extension`) olduğundan emin ol. ChromeOS dosya yöneticisinde "Linux dosyaları" bölümünden erişebilirsin.

---

## ADIM 3: Test Et

### A. Sağlık Kontrolü
- Eklenti ikonuna tıkla (popup açılır).
- Sunucu durumu **"AÇIK ✓"** olmalı.

### B. Pasif İzleme Testi
1. Yeni sekmede `https://chatgpt.com` aç (giriş yapmış ol).
2. Popup'ta sekme otomatik listelenmeli.
3. ChatGPT'ye elle bir soru sor.
4. Content script otomatik olarak yanıtı yakalar ve localhost'a gönderir.
5. **Kali terminalinde** veri logunu gör.

### C. Manuel Yakalama Testi
1. AI sekmesinde bir sohbet varken popup'tan **"📸 Yakala"** butonuna bas.
2. Sayfadaki mevcut yanıtlar toplanıp sunucuya gönderilir.

### D. DOM İnceleme (Debug)
1. Popup'tan **"🔍 DOM İncele"** butonuna bas.
2. AI sekmesinde **F12 → Console** aç.
3. `[PASEON-DEBUG]` loglarıyla DOM yapısını gör.

---

## Debug İpuçları

- **Tüm loglar konsoldadır:** AI sekmesinin konsolunda `[PASEON-DEBUG]` filtresini kullan.
- **Background worker logları:** `chrome://extensions` → Paseon → "Service Worker" linkine tıkla → Console.
- **Sunucu logları:** Kali terminalinde `[PASEON-SERVER]` etiketleriyle görünür.
- **Log dosyası:** `paseon/server/paseon_logs.json` dosyasında tüm yakalanan veriler JSON olarak saklanır.
- **Logları görüntüle:** `http://localhost:3000/logs` adresinden.
- **Logları temizle:** `curl -X DELETE http://localhost:3000/logs`

---

## Bilinen Kısıtlamalar (MVP)

- Seçiciler (selectors) AI sitelerinin DOM güncellemeleriyle bozulabilir → konsol logları ile debug et, `content.js` içindeki `getSelectorMap()` fonksiyonunu güncelle.
- Kimlik doğrulama yok → sadece localhost'ta çalışır.
- Tek seferde tek sekmeye enjeksiyon yapılır.
