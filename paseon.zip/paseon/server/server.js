// ============================================================================
// PASEON SERVER v0.1.0
// ============================================================================
// Basit Express sunucusu. Veriyi alır, terminale basar, dosyaya yazar.
// ============================================================================

const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = 3000;
const LOG_FILE = path.join(__dirname, "paseon_logs.json");
const PREFIX = "[PASEON-SERVER]";

// ---------------------------------------------------------------------------
// Middleware
// ---------------------------------------------------------------------------
app.use(cors()); // Tüm origin'lere izin ver (MVP: güvenlik yok)
app.use(express.json({ limit: "5mb" }));

// Request logger middleware
app.use((req, res, next) => {
  console.log(
    `${PREFIX} 📥 ${req.method} ${req.url} | IP: ${req.ip} | Content-Length: ${req.headers["content-length"] || "N/A"}`
  );
  next();
});

// ---------------------------------------------------------------------------
// Yardımcı: Dosyaya log yaz
// ---------------------------------------------------------------------------
function appendToLogFile(entry) {
  try {
    let logs = [];
    if (fs.existsSync(LOG_FILE)) {
      const raw = fs.readFileSync(LOG_FILE, "utf-8");
      logs = JSON.parse(raw);
    }
    logs.push(entry);
    fs.writeFileSync(LOG_FILE, JSON.stringify(logs, null, 2), "utf-8");
    console.log(`${PREFIX} 💾 Log dosyasına yazıldı. Toplam kayıt: ${logs.length}`);
  } catch (err) {
    console.error(`${PREFIX} ❌ Dosya yazma hatası:`, err.message);
  }
}

// ---------------------------------------------------------------------------
// ROUTES
// ---------------------------------------------------------------------------

// GET /status - Sağlık kontrolü
app.get("/status", (req, res) => {
  const status = {
    status: "online",
    service: "paseon-server",
    version: "0.1.0",
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    logFile: LOG_FILE,
    logCount: (() => {
      try {
        if (fs.existsSync(LOG_FILE)) {
          return JSON.parse(fs.readFileSync(LOG_FILE, "utf-8")).length;
        }
        return 0;
      } catch {
        return 0;
      }
    })(),
  };
  console.log(`${PREFIX} 🏥 Sağlık kontrolü → AÇIK`);
  res.json(status);
});

// POST /log - AI yanıtlarını al ve logla
app.post("/log", (req, res) => {
  const payload = req.body;

  console.log(`${PREFIX} ═══════════════════════════════════════════`);
  console.log(`${PREFIX} 📨 YENİ VERİ GELDİ`);
  console.log(`${PREFIX} ═══════════════════════════════════════════`);
  console.log(`${PREFIX} Kaynak     : ${payload.source || "bilinmiyor"}`);
  console.log(`${PREFIX} URL        : ${payload.url || "N/A"}`);
  console.log(`${PREFIX} Zaman      : ${payload.timestamp || new Date().toISOString()}`);
  console.log(`${PREFIX} Karakter   : ${payload.charCount || "N/A"}`);
  console.log(`${PREFIX} Yakalama   : ${payload.captureMode || "auto"}`);
  console.log(`${PREFIX} ───────────────────────────────────────────`);

  if (payload.responseText) {
    // İlk 500 karakteri terminale bas
    const preview = payload.responseText.substring(0, 500);
    console.log(`${PREFIX} 📝 YANIT ÖNİZLEME (ilk 500 karakter):`);
    console.log(`${PREFIX} ${preview}`);
    if (payload.responseText.length > 500) {
      console.log(`${PREFIX} ... (${payload.responseText.length - 500} karakter daha)`);
    }
  }

  if (payload.allResponses && Array.isArray(payload.allResponses)) {
    console.log(`${PREFIX} 📋 Tüm yanıt blokları: ${payload.allResponses.length} adet`);
    payload.allResponses.forEach((r, i) => {
      console.log(`${PREFIX}   [${i}] ${r.substring(0, 100)}...`);
    });
  }

  console.log(`${PREFIX} ═══════════════════════════════════════════`);

  // Dosyaya kaydet
  const logEntry = {
    receivedAt: new Date().toISOString(),
    ...payload,
  };
  appendToLogFile(logEntry);

  res.json({
    status: "logged",
    message: "Veri başarıyla alındı ve loglandı.",
    entryId: Date.now(),
  });
});

// GET /logs - Kayıtlı logları görüntüle (debug amaçlı)
app.get("/logs", (req, res) => {
  try {
    if (fs.existsSync(LOG_FILE)) {
      const logs = JSON.parse(fs.readFileSync(LOG_FILE, "utf-8"));
      console.log(`${PREFIX} 📂 Log dosyası okundu. ${logs.length} kayıt.`);
      res.json({ count: logs.length, logs: logs });
    } else {
      res.json({ count: 0, logs: [] });
    }
  } catch (err) {
    console.error(`${PREFIX} ❌ Log okuma hatası:`, err.message);
    res.status(500).json({ error: err.message });
  }
});

// DELETE /logs - Logları temizle (debug amaçlı)
app.delete("/logs", (req, res) => {
  try {
    fs.writeFileSync(LOG_FILE, "[]", "utf-8");
    console.log(`${PREFIX} 🗑️ Log dosyası temizlendi.`);
    res.json({ status: "cleared" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// START
// ---------------------------------------------------------------------------
app.listen(PORT, () => {
  console.log("");
  console.log(`${PREFIX} ╔══════════════════════════════════════════╗`);
  console.log(`${PREFIX} ║   PASEON SERVER v0.1.0 BAŞLATILDI        ║`);
  console.log(`${PREFIX} ╠══════════════════════════════════════════╣`);
  console.log(`${PREFIX} ║ Adres  : http://localhost:${PORT}            ║`);
  console.log(`${PREFIX} ║ Status : http://localhost:${PORT}/status      ║`);
  console.log(`${PREFIX} ║ Logs   : http://localhost:${PORT}/logs        ║`);
  console.log(`${PREFIX} ╚══════════════════════════════════════════╝`);
  console.log("");
  console.log(`${PREFIX} 🟢 Eklentiden veri bekleniyor...`);
  console.log("");
});
